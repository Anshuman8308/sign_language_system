import Loader from './Loader.jsx';

const variants = {
  primary: 'bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500',
  secondary: 'bg-gray-200 text-gray-800 hover:bg-gray-300 focus:ring-gray-500',
  danger: 'bg-red-600 text-white hover:bg-red-700 focus:ring-red-500',
  outline: 'border-2 border-blue-600 text-blue-600 hover:bg-blue-50 focus:ring-blue-500',
};

const Button = ({ children, variant = 'primary', type = 'button', isLoading = false, disabled = false, className = '', onClick, ...props }) => {
  const base = 'inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2';
  const cls = `${base} ${variants[variant]} ${disabled || isLoading ? 'opacity-50 cursor-not-allowed' : ''} ${className}`;

  return (
    <button type={type} className={cls} disabled={disabled || isLoading} onClick={onClick} {...props}>
      {isLoading ? <Loader size="sm" /> : children}
    </button>
  );
};

export default Button;
